import React from 'react'
import { Link } from 'react-router-dom'
import { AiOutlineInfoCircle } from 'react-icons/ai'

export default function Home() {
    return (
        <>
            <div className="hero-section mb-5">
                <img src={process.env.PUBLIC_URL + "images/bg.jpg"} className="bg" alt="" />
                <div className="row content align-items-center mx-0">
                    <div className="col-lg-6 px-0  col-12">
                        <h1 className="fw-600 col-lg-10 col-12">Discover, collect, and sell extraordinary NFTs</h1>
                        <p className="text-faded fs-4 my-3 mb-md-5 col-lg-6 col-12">On the world's first & largest NFT marketplace</p>
                        <div className="col-lg-8 px-0 col-12 row mx-0  ">
                            <Link to="" className="btn-1 col-sm-6 col-12 mt-sm-0 mt-3 text-center ">Explore</Link>
                            <Link to="" className="btn-dark col-sm-6 col-12 mt-sm-0 mt-3 text-center " >Create</Link>
                        </div>
                    </div>

                    <div className="col-lg-6 col-12 px-0 mt-lg-0 mt-3">
                        <div className="hero-card">
                            <img src={process.env.PUBLIC_URL + "images/bg.jpg"} className="top" alt="" />
                            <div className="d-flex align-items-center justify-content-between p-3">
                                <div className="d-flex align-items-center">
                                    <img src={process.env.PUBLIC_URL + "images/bg.jpg"} className="small-img" alt="" />
                                    <div className="d-flex flex-column ps-3">
                                        <span style={{ lineHeight: "20px" }} className="text-small-2 fw-600">Make Yourself at Home #48</span>
                                        <Link to="" className="text-small-2 fw-600">brookedidonato</Link>
                                    </div>
                                </div>
                                    <AiOutlineInfoCircle className="fs-5 text-faded" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

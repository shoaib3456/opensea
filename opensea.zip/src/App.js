import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Home from './Components/Home'
import Explore from './Components/Explore'
import Create from './Components/Create'
import Collection from './Components/Collection'
import Details from './Components/Details'
import Header from './Components/Elements/Header'
import Footer from './Components/Elements/Footer'


function App() {
    return (
        <>
            <Router>
                <Header />
                <Switch>
                    <Route path="/" exact>
                        <Home/>
                    </Route>
                    <Route path="/explore" >
                        <Explore/>
                    </Route>
                    <Route path="/create" >
                        <Create/>
                    </Route>
                    <Route path="/collection" >
                        <Collection/>
                    </Route>
                    <Route path="/details" >
                        <Details/>
                    </Route>

                    <Route  >
                        <h1 className="d-flex justify-content-center text-center pt-5 mt-5">404</h1>
                    </Route>
                </Switch>

                <Footer />
            </Router>
        </>
    )
}

export default App;
